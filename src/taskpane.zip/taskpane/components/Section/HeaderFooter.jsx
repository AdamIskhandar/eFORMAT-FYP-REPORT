import React, { useState } from "react";
import { makeStyles, Button, Input, Field, Text } from "@fluentui/react-components";
import { setReportHeader, setReportFooter } from "./utils/header-footer-utils";

/* global Word */

const useStyles = makeStyles({
  ContentWrapper: {
    paddingLeft: "10px",
  },
  heading: {
    color: "white",
    fontSize: "20px",
  },
  subheading: {
    color: "white",
    fontSize: "16px",
    margin: "12px 0 6px 0",
  },
  content: {
    paddingLeft: "25px",
    display: "flex",
    flexDirection: "column",
    gap: "10px",
    maxWidth: "320px",
  },
  note: {
    color: "#c7c7c7",
  },
  wrapButton: {
    display: "flex",
    justifyContent: "flex-end",
  },
  status: {
    display: "block",
    color: "#9fd89f",
  },
  error: {
    display: "block",
    color: "#e07a7a",
  },
});

export default function HeaderFooter() {
  const styles = useStyles();

  const [authorName, setAuthorName] = useState("");
  const [shortTitle, setShortTitle] = useState("");
  const [subjectCode, setSubjectCode] = useState("FYP4132");
  const [headerMsg, setHeaderMsg] = useState({ text: "", isError: false });
  const [footerMsg, setFooterMsg] = useState({ text: "", isError: false });

  async function handleSetHeader() {
    if (!authorName.trim() || !shortTitle.trim()) {
      setHeaderMsg({ text: "Type your name and the FYP title first.", isError: true });
      return;
    }
    try {
      await Word.run(async (context) => {
        await setReportHeader(context, authorName.trim(), shortTitle.trim());
      });
      setHeaderMsg({
        text: "Header set from section 3 onward (not on the cover pages).",
        isError: false,
      });
    } catch (err) {
      console.error(err);
      setHeaderMsg({ text: err.message || "Could not set the header.", isError: true });
    }
  }

  async function handleSetFooter() {
    if (!subjectCode.trim()) {
      setFooterMsg({ text: "Type the subject code first.", isError: true });
      return;
    }
    try {
      await Word.run(async (context) => {
        await setReportFooter(context, subjectCode.trim());
      });
      setFooterMsg({
        text: "Footer set from section 3 onward. Page numbers start at 3 on the Title Page.",
        isError: false,
      });
    } catch (err) {
      console.error(err);
      setFooterMsg({ text: err.message || "Could not set the footer.", isError: true });
    }
  }

  const msg = (m) =>
    m.text && <Text className={m.isError ? styles.error : styles.status}>{m.text}</Text>;

  return (
    <div className={styles.ContentWrapper}>
      <h2 className={styles.heading}>Header &amp; Footer</h2>
      <div className={styles.content}>
        <Text className={styles.note}>
          Shown from section 3 (the Title Page) onward. The cover pages in sections 1 and 2 stay
          without a header or footer. Click again any time to change the text.
        </Text>

        <h3 className={styles.subheading}>Header</h3>
        <Field label="Author's name (left)">
          <Input
            placeholder="e.g. Alkis A. Stavrinides"
            value={authorName}
            onChange={(_, data) => setAuthorName(data.value)}
          />
        </Field>
        <Field label="FYP title, shortened if needed (right)">
          <Input
            placeholder="e.g. Asset Management System"
            value={shortTitle}
            onChange={(_, data) => setShortTitle(data.value)}
          />
        </Field>
        <div className={styles.wrapButton}>
          <Button appearance="primary" shape="circular" onClick={handleSetHeader}>
            Set Header
          </Button>
        </div>
        {msg(headerMsg)}

        <h3 className={styles.subheading}>Footer</h3>
        <Field label="Subject code (left)">
          <Input value={subjectCode} onChange={(_, data) => setSubjectCode(data.value)} />
        </Field>
        <Text className={styles.note}>Right side shows &quot;Page X of Y&quot; automatically.</Text>
        <div className={styles.wrapButton}>
          <Button appearance="primary" shape="circular" onClick={handleSetFooter}>
            Set Footer
          </Button>
        </div>
        {msg(footerMsg)}
      </div>
    </div>
  );
}
