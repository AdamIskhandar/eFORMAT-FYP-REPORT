import React, { useState, useEffect, useCallback } from "react";
import {
  makeStyles,
  Button,
  Text,
  Field,
  Input,
  Dropdown,
  Option,
  Divider,
} from "@fluentui/react-components";
import {
  generateTableOfContents,
  updateTableOfContents,
  listParentHeadings,
  addSubheading,
  refreshContentsPageNumbers,
} from "../Section/utils/toc-generator-utils";
import { REPORT_STRUCTURE } from "../Section/utils/toc-template-config";

/* global Word */

const useStyles = makeStyles({
  ContentWrapper: {
    paddingLeft: "10px",
  },
  heading: {
    color: "white",
    fontSize: "20px",
  },
  subheading: {
    color: "white",
    fontSize: "16px",
    margin: "6px 0 0 0",
  },
  Wrapper: {
    paddingLeft: "25px",
    display: "flex",
    flexDirection: "column",
    gap: "10px",
    maxWidth: "320px",
  },
  note: {
    color: "#c7c7c7",
  },
  status: {
    display: "block",
    marginTop: "4px",
    color: "#9fd89f",
  },
  error: {
    display: "block",
    marginTop: "4px",
    color: "#e07a7a",
  },
  buttonRow: {
    display: "flex",
    gap: "10px",
    flexWrap: "wrap",
  },
});

const LINK_TIP = "Ctrl+Click an entry to jump to that page.";

export default function TableOfContents() {
  const styles = useStyles();

  const [genMsg, setGenMsg] = useState({ text: "", isError: false });
  const [updMsg, setUpdMsg] = useState({ text: "", isError: false });
  const [addMsg, setAddMsg] = useState({ text: "", isError: false });

  const [parents, setParents] = useState([]);
  const [parentPrefix, setParentPrefix] = useState("");
  const [title, setTitle] = useState("");

  const refreshParents = useCallback(async () => {
    try {
      await Word.run(async (context) => {
        const list = await listParentHeadings(context);
        setParents(list);
        setParentPrefix((current) => (list.some((p) => p.prefix === current) ? current : ""));
      });
    } catch (err) {
      console.error(err);
    }
  }, []);

  useEffect(() => {
    refreshParents();
  }, [refreshParents]);

  // Word finishes laying out the pages in the background AFTER the add-in's
  // changes; page numbers read before that all show the same early page.
  // So refresh them again a moment later (like pressing F9), twice to cover
  // slower/longer documents.
  function refreshPageNumbersLater() {
    [1500, 4000].forEach((delay) =>
      setTimeout(() => {
        Word.run((context) => refreshContentsPageNumbers(context)).catch((err) =>
          console.warn("Delayed page-number refresh failed (press F9 in Word).", err)
        );
      }, delay)
    );
  }

  async function run(setMsg, work, fallback) {
    try {
      await Word.run(async (context) => {
        setMsg({ text: await work(context), isError: false });
      });
      refreshPageNumbersLater();
    } catch (err) {
      console.error(err);
      // Word's errors are vague (e.g. "GeneralException"); add where it happened.
      const where = err?.debugInfo?.errorLocation ? ` (at ${err.debugInfo.errorLocation})` : "";
      setMsg({ text: `${err.message || fallback}${where}`, isError: true });
    }
  }

  async function handleGenerate() {
    await run(
      setGenMsg,
      async (context) => {
        const { created, count } = await generateTableOfContents(context, REPORT_STRUCTURE);
        return created
          ? `Contents page and all chapter headings generated (${count} entries). ${LINK_TIP}`
          : "Already generated. Use Update Table of Contents to refresh it.";
      },
      "Could not generate the Table of Contents."
    );
    refreshParents();
  }

  async function handleUpdate() {
    await run(
      setUpdMsg,
      async (context) => {
        const { count } = await updateTableOfContents(context);
        return `Table of Contents updated (${count} entries) with current page numbers. ${LINK_TIP}`;
      },
      "Could not update the Table of Contents."
    );
    refreshParents();
  }

  async function handleAdd() {
    if (!parentPrefix) {
      setAddMsg({ text: "Choose which heading to add it under.", isError: true });
      return;
    }
    await run(
      setAddMsg,
      async (context) => {
        const { text } = await addSubheading(context, parentPrefix, title);
        setTitle("");
        return `Added "${text}" and updated the Table of Contents.`;
      },
      "Could not add the subheading."
    );
    refreshParents();
  }

  const selected = parents.find((p) => p.prefix === parentPrefix);
  const msg = (m) =>
    m.text && <Text className={m.isError ? styles.error : styles.status}>{m.text}</Text>;

  return (
    <div className={styles.ContentWrapper}>
      <h2 className={styles.heading}>5) Table of Contents</h2>
      <div className={styles.Wrapper}>
        <Text className={styles.note}>
          Generates the CONTENTS page and every chapter heading from the report template. This only
          runs once - it won&apos;t overwrite anything you&apos;ve written.
        </Text>
        <Button appearance="primary" onClick={handleGenerate}>
          Generate Table of Contents
        </Button>
        {msg(genMsg)}

        <Divider />

        <Text className={styles.note}>
          Added, renamed or deleted a heading, or the pages moved? Update rebuilds the CONTENTS from
          the headings in your document and refreshes every page number. Click it again after adding
          content, so the page numbers stay right.
        </Text>
        <Button appearance="primary" onClick={handleUpdate}>
          Update Table of Contents
        </Button>
        {msg(updMsg)}

        <Divider />

        <h3 className={styles.subheading}>Add a subheading</h3>
        <Text className={styles.note}>
          Adds the next number under the heading you choose (under 3.3 it becomes 3.3.5), formats
          it, and updates the Table of Contents.
        </Text>
        <Field label="Add under">
          <Dropdown
            placeholder="Choose a heading"
            value={selected ? selected.text : ""}
            selectedOptions={parentPrefix ? [parentPrefix] : []}
            onOptionSelect={(_, data) => setParentPrefix(data.optionValue)}
          >
            {parents.map((p) => (
              <Option key={p.prefix} value={p.prefix} text={p.text}>
                {`${"  ".repeat(p.level - 1)}${p.text}`}
              </Option>
            ))}
          </Dropdown>
        </Field>
        <Field label="Subheading title">
          <Input
            placeholder="e.g. Phase 5"
            value={title}
            onChange={(_, data) => setTitle(data.value)}
          />
        </Field>
        <div className={styles.buttonRow}>
          <Button appearance="primary" onClick={handleAdd}>
            Add Subheading
          </Button>
          <Button appearance="secondary" onClick={refreshParents}>
            Refresh list
          </Button>
        </div>
        {msg(addMsg)}
      </div>
    </div>
  );
}
