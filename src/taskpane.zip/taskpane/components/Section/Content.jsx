import React, { useState } from "react";
import {
  makeStyles,
  useId,
  Dropdown,
  Option,
  Button,
  Text,
  Divider,
  Table,
  TableHeader,
  TableHeaderCell,
  TableBody,
  TableRow,
  TableCell,
  TableCellLayout,
} from "@fluentui/react-components";
import { CONTENT_FORMAT, formatSelection, formatWholeReport } from "./utils/content-format-utils";

/* global Word */

const useStyles = makeStyles({
  ContentWrapper: { paddingLeft: "10px" },
  heading: { color: "white", fontSize: "20px" },
  contentCover: {
    paddingLeft: "25px",
    display: "flex",
    flexDirection: "column",
    gap: "10px",
    maxWidth: "320px",
  },
  label: { margin: "6px 0 0 0" },
  note: { color: "#c7c7c7" },
  wrapButton: { display: "flex", justifyContent: "flex-end" },
  status: { display: "block", color: "#9fd89f" },
  error: { display: "block", color: "#e07a7a" },
});

// Guide only - the real values are CONTENT_FORMAT in content-format-utils.js.
const GUIDE = [
  { element: "Font/Size (Heading)", format: "Arial / 16-point / Bold" },
  { element: "Font/Size (Sub heading)", format: "Arial / 14-point / Bold" },
  { element: "Font/Size (Content)", format: "Arial / 11-point" },
  { element: "Font/Size (in table) / Label Figure or Table", format: "Arial / 10-point" },
  { element: "Spacing", format: "1.5" },
  { element: "Alignment", format: "Justify" },
];

const KINDS = Object.entries(CONTENT_FORMAT).map(([key, f]) => ({ key, label: f.label }));

export default function Content() {
  const styles = useStyles();
  const dropdownId = useId("content-kind");

  const [kind, setKind] = useState("");
  const [selMsg, setSelMsg] = useState({ text: "", isError: false });
  const [allMsg, setAllMsg] = useState({ text: "", isError: false });

  async function handleFormatSelection() {
    if (!kind) {
      setSelMsg({ text: "Choose what the selected text is first.", isError: true });
      return;
    }
    try {
      await Word.run(async (context) => {
        const n = await formatSelection(context, kind);
        setSelMsg({
          text: `Formatted ${n} paragraph${n === 1 ? "" : "s"} as ${CONTENT_FORMAT[kind].label}.`,
          isError: false,
        });
      });
    } catch (err) {
      console.error(err);
      setSelMsg({ text: err.message || "Could not format the selection.", isError: true });
    }
  }

  async function handleFormatAll() {
    try {
      await Word.run(async (context) => {
        const { content, small } = await formatWholeReport(context);
        setAllMsg({
          text: `Formatted ${content} content paragraph${content === 1 ? "" : "s"} and ${small} table/caption line${small === 1 ? "" : "s"}.`,
          isError: false,
        });
      });
    } catch (err) {
      console.error(err);
      setAllMsg({ text: err.message || "Could not format the report.", isError: true });
    }
  }

  const msg = (m) => m.text && <Text className={m.isError ? styles.error : styles.status}>{m.text}</Text>;

  return (
    <div className={styles.ContentWrapper}>
      <h2 className={styles.heading}>5) Content</h2>
      <div className={styles.contentCover}>
        <p className={styles.label}>Guide for Content</p>
        <Table aria-label="Content format guide">
          <TableHeader>
            <TableRow>
              <TableHeaderCell>Element</TableHeaderCell>
              <TableHeaderCell>Format Style</TableHeaderCell>
            </TableRow>
          </TableHeader>
          <TableBody>
            {GUIDE.map((g) => (
              <TableRow key={g.element}>
                <TableCell>
                  <TableCellLayout>{g.element}</TableCellLayout>
                </TableCell>
                <TableCell>{g.format}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>

        <Divider />

        <p className={styles.label}>Format the selected text</p>
        <Text className={styles.note}>
          Put the cursor in a paragraph (or select several), choose what it is, then click Set Format.
          Content also gets 1.5 spacing and justify.
        </Text>
        <Dropdown
          id={dropdownId}
          placeholder="Select the element"
          value={kind ? CONTENT_FORMAT[kind].label : ""}
          selectedOptions={kind ? [kind] : []}
          onOptionSelect={(_, data) => setKind(data.optionValue)}
        >
          {KINDS.map((k) => (
            <Option key={k.key} value={k.key}>
              {k.label}
            </Option>
          ))}
        </Dropdown>
        <div className={styles.wrapButton}>
          <Button shape="circular" appearance="primary" onClick={handleFormatSelection}>
            Set Format
          </Button>
        </div>
        {msg(selMsg)}

        <Divider />

        <p className={styles.label}>Format the whole report</p>
        <Text className={styles.note}>
          From Chapter 1 to the end: content becomes Arial 11, 1.5 spacing, justify; text inside
          tables and Figure/Table captions become Arial 10. Headings and the pages before Chapter 1
          are not changed. Bold or italic words you set yourself are kept.
        </Text>
        <div className={styles.wrapButton}>
          <Button shape="circular" appearance="primary" onClick={handleFormatAll}>
            Format Whole Report
          </Button>
        </div>
        {msg(allMsg)}
      </div>
    </div>
  );
}
