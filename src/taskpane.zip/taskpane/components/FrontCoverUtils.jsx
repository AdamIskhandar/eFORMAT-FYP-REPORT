import React, { useState, useEffect } from "react";
import {
  makeStyles,
  useId,
  Dropdown,
  Option,
  Button,
  Text,
  TableBody,
  TableCell,
  TableRow,
  Table,
  TableHeader,
  TableHeaderCell,
  TableCellLayout,
  PresenceBadgeStatus,
  Avatar,
} from "@fluentui/react-components";
import { generateFrontCover, isFrontCoverGenerated } from "./Section/utils/front-cover-utils";

/* global Word */

const useStyles = makeStyles({
  MostFrontCoverWrapper: {
    paddingLeft: "10px",
  },
  heading: {
    color: "white",
    fontSize: "20px",
  },
  paragprahp: {
    paddingLeft: "25px",
    fontSize: "15px",
  },

  label: {
    marginBottom: "10px",
  },

  contentMostFrontCover: {
    paddingLeft: "25px",
  },

  button: {
    marginTop: "10px",
  },

  wrapButton: {
    display: "flex",
    justifyContent: "flex-end",
    marginRight: "40px",
  },

  status: {
    display: "block",
    marginTop: "6px",
    color: "#9fd89f",
  },

  sectionGap: {
    marginTop: "18px",
  },
});

// Guide tables only - the real values used when generating live in
// front-cover-utils.js. Kept here so students can see the spec at a glance.
const tableColumns = [
  { columnKey: "element", label: "Element" },
  { columnKey: "formatStyle", label: "Format Style" },
];

const itemsMostFrontCover = [
  { element: "Top Margin", format: "4 cm" },
  { element: "Bottom Margin", format: "4 cm" },
  { element: "Left Margin", format: "3.2 cm" },
  { element: "Right Margin", format: "3.2 cm" },
  { element: "UNIVERSITI POLY-TECH MALAYSIA", format: "Arial Bold 20 - First Line on page" },
  { element: "Project Title", format: "Arial Bold 20 - Centre of Page" },
  { element: "Student's Full Name", format: "Arial Bold 20 - Last line on page (red)" },
  {
    element: "Programme (e.g. Computer Application Development)",
    format: "Arial Bold 20 - last line, specialisation in red",
  },
];

function GuideTable({ title, items, maxWidth }) {
  const styles = useStyles();
  return (
    <>
      <p className={styles.label}>{title}</p>
      <Table arial-label="Default table" style={{ maxWidth }}>
        <TableHeader>
          <TableRow>
            {tableColumns.map((column) => (
              <TableHeaderCell key={column.columnKey}>{column.label}</TableHeaderCell>
            ))}
          </TableRow>
        </TableHeader>
        <TableBody>
          {items.map((item) => (
            <TableRow key={item.element}>
              <TableCell>
                <TableCellLayout>{item.element}</TableCellLayout>
              </TableCell>
              <TableCell>{item.format}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </>
  );
}

export default function FrontCoverUtils() {
  const styles = useStyles();
  const [status, setStatus] = useState("");
  const [alreadyDone, setAlreadyDone] = useState(false);

  useEffect(() => {
    setAlreadyDone(isFrontCoverGenerated());
  }, []);

  async function handleGenerate() {
    try {
      await Word.run(async (context) => {
        const { created } = await generateFrontCover(context);
        setStatus(
          created
            ? "Most-front Cover generated above the Title Page. Replace the [bracketed] placeholders with your own text."
            : "Most-front Cover was already generated - edit the bracketed placeholders directly in the document."
        );
        setAlreadyDone(true);
      });
    } catch (err) {
      console.error(err);
      setStatus(err.message || "Could not generate the Front Cover.");
    }
  }

  return (
    <div className={styles.MostFrontCoverWrapper}>
      <h2 className={styles.heading}>Front Cover</h2>

      <div className={styles.contentMostFrontCover}>
        <p className={styles.label}>
          Generates the Most-front Cover page, with its own 4cm / 3.2cm margin, placed above the
          Title Page. This only runs once. (Inside Cover comes later.)
        </p>
        <div className={styles.wrapButton}>
          <Button appearance="primary" shape="circular" onClick={handleGenerate}>
            {alreadyDone ? "Front Cover Generated" : "Generate Front Cover"}
          </Button>
        </div>
        {status && <Text className={styles.status}>{status}</Text>}

        <div className={styles.sectionGap}>
          <GuideTable
            title="Guide for Most-front Cover"
            items={itemsMostFrontCover}
            maxWidth="320px"
          />
        </div>
      </div>
    </div>
  );
}
